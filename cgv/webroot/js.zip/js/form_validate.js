var Script = function () {

	$().ready(function() {
		 $('#update_grade').validate({
            rules: {
                grade: {
                    required: true,
                    number: true
                }
              },
            messages: {     
                grade: {
                    required: "This field is required!",
                    number: "Type number only"
                }
            }
        });
	});


}();