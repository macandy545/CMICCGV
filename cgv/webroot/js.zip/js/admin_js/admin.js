$(document).ready(function(){
  //previewFile();
});

function previewFile(){
   var preview = document.querySelector('#img'); //selects the query named img
   var file    = document.querySelector('input[type=file]').files[0]; //sames as here
   var reader  = new FileReader();

   reader.onloadend = function () {
       preview.src = reader.result;
   }
   if (file) {
       reader.readAsDataURL(file); //reads the data as a URL
   } else {
       preview.src = "";
   }
}

function setfilename(val)
{
  var fileName = val.substr(val.lastIndexOf("\\")+1, val.length);
  document.getElementById("img2").value = fileName;
}
function prelimTotalGrade(id = null)
{
  if(id)
  {
    $.ajax({
      url:'prelimviewsubjecttotalgrade/'+id,
      type: 'post',
      dataType: 'json',
      success: function(response){
        $('#prelim_Subgrade').val(response);
      }
    });
  }
}
function midtermTotalGrade(id = null)
{
  if(id)
  {
    $.ajax({
      url:'midtermviewsubjecttotalgrade/'+id,
      type: 'post',
      dataType: 'json',
      success: function(response){
        $('#midterm_Subgrade').val(response);
      }
    });
  }
}
function sfinalTotalGrade(id = null)
{
  if(id)
  {
    $.ajax({
      url:'sfinalviewsubjecttotalgrade/'+id,
      type: 'post',
      dataType: 'json',
      success: function(response){
        $('#sfinal_Subgrade').val(response);
      }
    });
  }
}
function finalTotalGrade(id = null)
{
  if(id)
  {
    $.ajax({
      url:'finalviewsubjecttotalgrade/'+id,
      type: 'post',
      dataType: 'json',
      success: function(response){
        $('#final_Subgrade').val(response);
      }
    });
  }
}